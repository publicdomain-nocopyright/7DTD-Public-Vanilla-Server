logfile_content = open("log.txt").read()





#print(open("log.txt").seek(0, 2))
